#!/bin/bash

#atualização do servidor
echo "Atualizando Servidor..."
apt update -y
apt upgrade -y

echo "Instalando o serviço apache"
#Instalação do Apache 
apt install apache2 -y

echo "instalando o unzip´"
#Instalação do unzip
apt install unzip -y

echo "Reiniciando o serviço"
#Reinicia o servico apache
systemctl restart apache2

echo "Info para acesso ao serviço"
#mostra o ip da maquina para testar o servico
ip a
